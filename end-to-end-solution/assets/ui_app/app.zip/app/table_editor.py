from typing import (
    Literal, Dict, Union, Mapping, Sequence, TypeVar, MutableMapping, List, cast
)
import json
import logging

import pandas as pd
import streamlit as st
import io

from dynamodb_conn import DynamoDBConnection, DynamoDBItemType


logger = logging.getLogger(__name__)


class JSONError(RuntimeError): ...


DFOrMapping = TypeVar("DFOrMapping", pd.DataFrame, MutableMapping)


def _get_json_serializable_cols(df) -> List[str]:
    res = []
    _, row = next(df.iterrows())
    for label, value in row.items():
        if isinstance(value, (Mapping, Sequence)) and not isinstance(value, (str, bytes, bytearray)):
            res.append(label)
    return res


def _serialize_json_cols(df: pd.DataFrame, json_cols: Sequence[str]) -> pd.DataFrame:
    for json_col in json_cols:
        df[json_col] = df[json_col].apply(lambda o: json.dumps(o))
    return df


def _deserialize_json_cols(data: DFOrMapping, json_cols: Sequence[str]) -> DFOrMapping:
    for json_col in json_cols:
        try:
            deserializer = lambda s: json.loads(s) if s is not None else None
            if isinstance(data, pd.DataFrame):
                data[json_col] = data[json_col].apply(deserializer)
            elif isinstance(data, MutableMapping):
                if json_col in data:
                    data[json_col] = deserializer(data[json_col])
        except json.JSONDecodeError as e:
            raise JSONError(f"Invalid json string in column '{json_col}'!") from e
    return data



class DynamoDBTableEditor:

    _DATA_EDITOR_WIDGET_KEY: Literal["data_editor_widget"] = "data_editor_widget"
    _DATA_EDITOR_DATA_KEY: Literal["data_editor_data"] = "data_editor_data"
    _DATA_EDITOR_PROCESSED_KEY: Literal["data_editor_processed"] = "data_editor_processed"
    _DEFAULT_EDIT_INFO: Dict[str, Union[Mapping, Sequence]] = {
        "edited_rows": {},
        "added_rows": [],
        "deleted_rows": []
    }

    def __init__(self, connection: DynamoDBConnection, key_prefix="table_results_editor_") -> None:
        self.connection = connection
        self.key_prefix = key_prefix
        self.data_key = self.key_prefix + self._DATA_EDITOR_DATA_KEY
        self.widget_key = self.key_prefix + self._DATA_EDITOR_WIDGET_KEY
        self.processed_edits_key = self.key_prefix + self._DATA_EDITOR_PROCESSED_KEY
        if self.data_key in st.session_state:
            st.session_state.pop(self.data_key)
        if not self.data_key in st.session_state:
            st.session_state[self.data_key] = self.connection.items(ignore_cache=True)
        self.df = st.session_state[self.data_key]

    def edit(self) -> pd.DataFrame:
       
        json_cols = _get_json_serializable_cols(self.df)
        df = _serialize_json_cols(self.df.copy(), json_cols)
        df = self.df.copy()

        df_styled = df.style.set_properties(**{'font-size': '16pt'})

        edited_df = st.data_editor(
            df_styled,
            column_config={
                #"_index": st.column_config.TextColumn(required=True),
                'id': st.column_config.Column('id', disabled=True,),
                'question': st.column_config.Column('question', disabled=True),
                'answer': st.column_config.Column('answer', disabled=True),
                'ground_truth': st.column_config.Column('ground truth', disabled=True),
                'contexts': st.column_config.Column('contexts', disabled=True),
                'answer_relevancy': st.column_config.NumberColumn(
                    'answer relevancy',
                    min_value=0.00,
                    max_value=1.00,
                    step=0.01, 
                    disabled=True
                ),
                'truthfulness': st.column_config.NumberColumn(
                    'truthfulness', 
                    min_value=0.00,
                    max_value=1.00,
                    step=0.01, 
                    disabled=True
                ),
                'context_recall': st.column_config.NumberColumn(
                    'context recall',
                    min_value=0.00,
                    max_value=1.00,
                    step=0.01, 
                    disabled=True
                ),
                'context_precision': st.column_config.NumberColumn(
                    'context precision',
                    min_value=0.00,
                    max_value=1.00,
                    step=0.01, 
                    disabled=True
                )
            },
            use_container_width=True,
            
            key=self.widget_key,
            column_order=(
                "id",
                "question",
                "answer",
                "ground_truth",
                "contexts",
                "answer_relevancy",
                "truthfulness",
                "context_recall",
                "context_precision"
            )

        )

        try:
            edited_df = _deserialize_json_cols(edited_df, json_cols=json_cols)
        except JSONError as e:
            st.error(str(e), icon="🛑")
            st.stop()
        self.process_edits(json_cols)

        return edited_df

    @property
    def edit_info(self) -> Dict:
        return st.session_state.get(
            self.widget_key,
            default=self._DEFAULT_EDIT_INFO.copy()
        )

    @property
    def processed_edits(self) -> Dict:
        if not self.processed_edits_key in st.session_state:
            st.session_state[self.processed_edits_key] = self._DEFAULT_EDIT_INFO.copy()
        return st.session_state[self.processed_edits_key]


    @processed_edits.setter
    def processed_edits(self, value):
        st.session_state[self.processed_edits_key] = value

    def process_edits(self, json_cols: List[str]) :
        edit_info = self.edit_info
        logger.debug("Edit info: %s", edit_info)

        # edited_rows
        processed_edited_rows = self.processed_edits["edited_rows"]
        for idx, edited_row in edit_info["edited_rows"].items():
            index_val = self.df.index[int(idx)]
            edited_row = _deserialize_json_cols(edited_row, json_cols)
            if idx in processed_edited_rows and processed_edited_rows[idx] == edited_row:
                logger.debug(
                    "Item '%s' edit '%s' was already processed, continue...", index_val, edited_row
                )
                continue
            self.connection.modify_item(index_val, cast(DynamoDBItemType, edited_row))
            processed_edited_rows[idx] = edited_row
            logger.debug("Item '%s' edit '%s' was processed.", index_val, edited_row)
